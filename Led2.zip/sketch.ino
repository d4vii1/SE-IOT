int led_red = 13;
int led_blue = 12;

int btn_red = 10;
int btn_blue = 11;

int btn_state_red = 0;
int btn_state_blue = 0;

void setup() {
  pinMode(led_red, OUTPUT);
  pinMode(led_blue, OUTPUT);

  pinMode(btn_red, INPUT);
  pinMode(btn_blue, INPUT);
}

void loop() {

  btn_state_red = digitalRead(btn_red);
  btn_state_blue = digitalRead(btn_blue);

  // Controle do LED vermelho
  if (btn_state_red == HIGH) {
    digitalWrite(led_red, HIGH);
  } else {
    digitalWrite(led_red, LOW);
  }

  // Controle do LED azul
  if (btn_state_blue == HIGH) {
    digitalWrite(led_blue, HIGH);
  } else {
    digitalWrite(led_blue, LOW);
  }
}