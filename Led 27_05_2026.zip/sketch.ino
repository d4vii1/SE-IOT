int ledr = 8;
int ledy = 9;
int ledg = 10;


void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(ledr, OUTPUT);
  pinMode(ledy, OUTPUT);
  pinMode(ledg, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(ledr, HIGH);
  digitalWrite(ledy, LOW );
  digitalWrite(ledg, LOW );
  Serial.println("Vermelho");
  delay(3000);
  digitalWrite(ledr, HIGH);
  digitalWrite(ledy, LOW );
  digitalWrite(ledg, LOW );
  Serial.println("Amarelo");
  delay(3000);
  digitalWrite(ledr, HIGH);
  digitalWrite(ledy, LOW );
  digitalWrite(ledg, LOW );
  Serial.println("vermelho");
  delay(3000);
}
